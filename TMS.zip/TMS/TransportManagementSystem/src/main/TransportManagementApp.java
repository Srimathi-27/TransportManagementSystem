package main;

import java.util.*;
import entity.*;
import myexceptions.BookingNotFoundException;
import myexceptions.VehicleNotFoundException;
import dao.*;
import util.DBConnUtil;
public class TransportManagementApp {
    public static void main(String[] args) throws VehicleNotFoundException, BookingNotFoundException {
    	Scanner sc = new Scanner(System.in);
        TransportService service = new TransportServiceImpl();

        while (true) {
            System.out.println("\n===== Transport Management System =====");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Update Vehicle");
            System.out.println("3. Delete Vehicle");
            System.out.println("4. Schedule Trip");
            System.out.println("5. Cancel Trip");
            System.out.println("6. Book Trip");
            System.out.println("7. Cancel Booking");
            System.out.println("8. Allocate Driver");
            System.out.println("9. Deallocate Driver");
            System.out.println("10. View Bookings by Passenger");
            System.out.println("11. View Bookings by Trip");
            System.out.println("12. View Available Drivers");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Model: ");
                    String model = sc.nextLine();
                    System.out.print("Capacity: ");
                    double capacity = sc.nextDouble(); sc.nextLine();
                    System.out.print("Type (Truck/Van/Bus): ");
                    String type = sc.nextLine();
                    System.out.print("Status (Available/On Trip/Maintenance): ");
                    String status = sc.nextLine();
                    Vehicle vehicle = new Vehicle(0, model, capacity, type, status);
                    if (service.addVehicle(vehicle))
                        System.out.println("Vehicle added successfully.");
                    else
                        System.out.println("Failed to add vehicle.");
                    break;

                case 2:
                    System.out.print("Enter Vehicle ID to update: ");
                    int vId = sc.nextInt(); sc.nextLine();
                    System.out.print("Updated Model: ");
                    model = sc.nextLine();
                    System.out.print("Updated Capacity: ");
                    capacity = sc.nextDouble(); sc.nextLine();
                    System.out.print("Updated Type: ");
                    type = sc.nextLine();
                    System.out.print("Updated Status: ");
                    status = sc.nextLine();
                    vehicle = new Vehicle(vId, model, capacity, type, status);
                    if (service.updateVehicle(vehicle))
                        System.out.println("Vehicle updated.");
                    else
                        System.out.println("Update failed.");
                    break;

                case 3:
                	System.out.print("Enter Vehicle ID to delete: ");
                    int deleteId = sc.nextInt();
                    try {
                        if (service.deleteVehicle(deleteId))
                            System.out.println("Vehicle deleted.");
                    } catch (VehicleNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.print("Vehicle ID: ");
                    int vehicleId = sc.nextInt();
                    System.out.print("Route ID: ");
                    int routeId = sc.nextInt(); sc.nextLine();
                    System.out.print("Departure Date (YYYY-MM-DD): ");
                    String departure = sc.nextLine();
                    System.out.print("Arrival Date (YYYY-MM-DD): ");
                    String arrival = sc.nextLine();
                    if (service.scheduleTrip(vehicleId, routeId, departure, arrival))
                        System.out.println("Trip scheduled.");
                    else
                        System.out.println("Trip scheduling failed.");
                    break;

                case 5:
                    System.out.print("Trip ID to cancel: ");
                    int tripCancelId = sc.nextInt();
                    if (service.cancelTrip(tripCancelId))
                        System.out.println("Trip cancelled.");
                    else
                        System.out.println("Failed to cancel trip.");
                    break;

                case 6:
                    System.out.print("Trip ID: ");
                    int tripId = sc.nextInt();
                    System.out.print("Passenger ID: ");
                    int passengerId = sc.nextInt(); sc.nextLine();
                    System.out.print("Booking Date (YYYY-MM-DD): ");
                    String bookingDate = sc.nextLine();
                    if (service.bookTrip(tripId, passengerId, bookingDate))
                        System.out.println("Booking successful.");
                    else
                        System.out.println("Booking failed.");
                    break;

                case 7:
                	System.out.print("Booking ID to cancel: ");
                    int bookingId = sc.nextInt();
                    try {
                        if (service.cancelBooking(bookingId))
                            System.out.println("Booking cancelled.");
                    } catch (BookingNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 8:
                    System.out.print("Trip ID: ");
                    int tId = sc.nextInt();
                    System.out.print("Driver ID: ");
                    int dId = sc.nextInt();
                    if (service.allocateDriver(tId, dId))
                        System.out.println("Driver allocated.");
                    else
                        System.out.println("Driver allocation failed.");
                    break;

                case 9:
                    System.out.print("Trip ID: ");
                    tId = sc.nextInt();
                    if (service.deallocateDriver(tId))
                        System.out.println("Driver deallocated.");
                    else
                        System.out.println("Driver deallocation failed.");
                    break;

                case 10:
                    System.out.print("Passenger ID: ");
                    passengerId = sc.nextInt();
                    List<Booking> bookingsByPassenger = service.getBookingsByPassenger(passengerId);
                    bookingsByPassenger.forEach(System.out::println);
                    break;

                case 11:
                    System.out.print("Trip ID: ");
                    tripId = sc.nextInt();
                    List<Booking> bookingsByTrip = service.getBookingsByTrip(tripId);
                    bookingsByTrip.forEach(System.out::println);
                    break;

                case 12:
                    List<Driver> drivers = service.getAvailableDrivers();
                    drivers.forEach(System.out::println);
                    break;

                case 0:
                    System.out.println("Exiting system. Goodbye!");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
