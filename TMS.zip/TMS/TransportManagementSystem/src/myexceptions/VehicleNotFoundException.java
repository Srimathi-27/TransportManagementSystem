package myexceptions;

public class VehicleNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;
	// While deleting vehicle that doesn't exists
    public VehicleNotFoundException(String message) {
        super(message);
    }
}
