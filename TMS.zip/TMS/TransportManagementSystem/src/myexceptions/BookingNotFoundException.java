package myexceptions;

public class BookingNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	// while canceling booking with incorrect bookingId
    public BookingNotFoundException(String message) {
        super(message);
    }
}
