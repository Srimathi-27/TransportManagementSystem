package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                String url = DBPropertyUtil.getProperty("db.url");
                String user = DBPropertyUtil.getProperty("db.user");
                String password = DBPropertyUtil.getProperty("db.password");
                String driver = DBPropertyUtil.getProperty("db.driver");

                Class.forName(driver);  
                connection = DriverManager.getConnection(url, user, password);
                

            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Database connection failed.");
            }
        }
        return connection;
    }
}
