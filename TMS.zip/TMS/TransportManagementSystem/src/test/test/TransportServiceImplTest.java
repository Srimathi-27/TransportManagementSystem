package test;

import dao.TransportServiceImpl;
import entity.Driver;
import entity.Vehicle;
import myexceptions.BookingNotFoundException;
import myexceptions.VehicleNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TransportServiceImplTest {

    private TransportServiceImpl service;

    @BeforeEach
    public void setUp() {
        service = new TransportServiceImpl();
    }
    
    @Test
    
    void testAllocateDriverSuccessfully() {
        int tripId = 2;       
        int driverId = 1;     

        boolean result = service.allocateDriver(tripId, driverId);
        assertTrue(result, "Driver should be allocated to the trip successfully.");
    }
    
    @Test
    void testAddVehicleSuccessfully() {
        Vehicle vehicle = new Vehicle();
        vehicle.setModel("Ashok Leyland Falcon");
        vehicle.setCapacity(30.0);
        vehicle.setType("Bus");
        vehicle.setStatus("Available");

        boolean result = service.addVehicle(vehicle);
        assertTrue(result, "Vehicle should be added successfully.");
    }
    
    @Test
    void testBookingSuccessfully() {
        assertTrue(service.bookTrip(3, 1, "2025-04-10"));
    }
    
    @Test
    void testDeleteVehicleThrowsVehicleNotFoundException() {
        int invalidVehicleId = 9999;

        assertThrows(VehicleNotFoundException.class, () -> {
            service.deleteVehicle(invalidVehicleId);
        });
    }
    @Test
    void testCancelBookingThrowsBookingNotFoundException() {
        int invalidBookingId = 9999;

        assertThrows(BookingNotFoundException.class, () -> {
            service.cancelBooking(invalidBookingId);
        });
    }
    
    
}
