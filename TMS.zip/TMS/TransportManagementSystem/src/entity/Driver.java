package entity;

public class Driver {
    private int driverId;
    private String name;
    private String licenseNo;
    private String phone;

    
    public Driver(int driverId, String name, String licenseNo, String phone) {
        this.driverId = driverId;
        this.name = name;
        this.licenseNo = licenseNo;
        this.phone = phone;
    }

    // Getters and Setters
    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "\n--- Driver Details ---\n" +
               "Driver ID     : " + driverId + "\n" +
               "Name          : " + name + "\n" +
               "License No.   : " + licenseNo + "\n" +
               "Phone         : " + phone + "\n";
    }
}
