package dao;

import java.sql.*;
import java.util.*;

import entity.Booking;
import entity.Driver;
import entity.Vehicle;
import myexceptions.*;
import util.DBConnUtil;

public class TransportServiceImpl implements TransportService {
    private Connection conn = DBConnUtil.getConnection();

    @Override
    public boolean addVehicle(Vehicle vehicle) {
        String query = "INSERT INTO Vehicles (Model, Capacity, Type, Status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, vehicle.getModel());
            ps.setDouble(2, vehicle.getCapacity());
            ps.setString(3, vehicle.getType());
            ps.setString(4, vehicle.getStatus());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateVehicle(Vehicle vehicle) {
        String query = "UPDATE Vehicles SET Model=?, Capacity=?, Type=?, Status=? WHERE VehicleID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, vehicle.getModel());
            ps.setDouble(2, vehicle.getCapacity());
            ps.setString(3, vehicle.getType());
            ps.setString(4, vehicle.getStatus());
            ps.setInt(5, vehicle.getVehicleId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException {
        String query = "DELETE FROM Vehicles WHERE VehicleID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, vehicleId);
            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new VehicleNotFoundException("Vehicle not found with ID: " + vehicleId);
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            // You can choose to throw a RuntimeException or return false
            throw new RuntimeException("Error while deleting vehicle", e);
        }
    }

    @Override
    public boolean scheduleTrip(int vehicleId, int routeId, String departureDate, String arrivalDate) {
        String query = "INSERT INTO Trips (VehicleID, RouteID, DepartureDate, ArrivalDate, Status, TripType, MaxPassengers) VALUES (?, ?, ?, ?, 'Scheduled', 'Freight', 0)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, vehicleId);
            ps.setInt(2, routeId);
            ps.setString(3, departureDate);
            ps.setString(4, arrivalDate);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean cancelTrip(int tripId) {
        String query = "UPDATE Trips SET Status='Cancelled' WHERE TripID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, tripId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean bookTrip(int tripId, int passengerId, String bookingDate) {
        String query = "INSERT INTO Bookings (TripID, PassengerID, BookingDate, Status) VALUES (?, ?, ?, 'Confirmed')";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, tripId);
            ps.setInt(2, passengerId);
            ps.setString(3, bookingDate);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    @Override
    public boolean cancelBooking(int bookingId) throws BookingNotFoundException {
        String query = "UPDATE Bookings SET Status='Cancelled' WHERE BookingID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, bookingId);
            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error while cancelling booking", e);
        }
    }
   

    @Override
    public boolean allocateDriver(int tripId, int driverId) {
        String query = "UPDATE Trips SET DriverID=? WHERE TripID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, driverId);
            ps.setInt(2, tripId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deallocateDriver(int tripId) {
        String query = "UPDATE Trips SET DriverID=NULL WHERE TripID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, tripId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Booking> getBookingsByPassenger(int passengerId) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT * FROM Bookings WHERE PassengerID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, passengerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Booking booking = new Booking(
                    rs.getInt("BookingID"),
                    rs.getInt("TripID"),
                    rs.getInt("PassengerID"),
                    rs.getTimestamp("BookingDate").toLocalDateTime(),
                    rs.getString("Status")
                );
                bookings.add(booking);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }

    @Override
    public List<Booking> getBookingsByTrip(int tripId) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT * FROM Bookings WHERE TripID=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, tripId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Booking booking = new Booking(
                    rs.getInt("BookingID"),
                    rs.getInt("TripID"),
                    rs.getInt("PassengerID"),
                    rs.getTimestamp("BookingDate").toLocalDateTime(),
                    rs.getString("Status")
                );
                bookings.add(booking);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }

    @Override
    public List<Driver> getAvailableDrivers() {
        List<Driver> drivers = new ArrayList<>();
        String query = "SELECT * FROM drivers WHERE DriverID NOT IN (SELECT DriverID FROM Trips WHERE DriverID IS NOT NULL)";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Driver driver = new Driver(
                    rs.getInt("DriverID"),
                    rs.getString("Name"),
                    rs.getString("LicenseNo"),
                    rs.getString("Phone")
                );
                drivers.add(driver);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return drivers;
    }
}


